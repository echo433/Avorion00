return {
    loglevel =              { value = 1,               description = "Global loglevel for the galaxy. Will be set to 4 in dev mode, if loglevel is < 4.", sorting = 1 },
}