return {
    maxTradeDuration =      { value = 300,             description = "Max trade duration (s) per station - skip docking when its over. Prevents ship of getting stuck.", sorting = 1 },
    numMaxRoutes =          { value = 50,              description = "Max amount of routes per player", sorting = 2 },
    numMaxSectors =         { value = 50,              description = "Max amount of sectors per route", sorting = 3 },
    numMaxGoods =           { value = 50,              description = "Max amount of goods per route", sorting = 4 },
    numMaxProtocols =       { value = 50,              description = "Max amount of protocols per route", sorting = 5 },
    dateFormat =            { value = "default",       description = "Date format. Set to 'default' or a lua date format string (e.g. '%x %X'). Overrides translations.", sorting = 6 },
}