
scriptCachingEnabled = true
achievementsEnabled = true
forceEnabling = true

mods = 
{
    {workshopid = "1720259598", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\1720259598"},
    {workshopid = "1722412006", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\1722412006"},
    {workshopid = "2005799455", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2005799455"},
    {workshopid = "2008725361", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2008725361"},
    {workshopid = "2010035911", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2010035911"},
    {workshopid = "2230451945", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2230451945"},
    {workshopid = "2280867170", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2280867170"},
    {workshopid = "2701395322", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2701395322"},
    {workshopid = "2767486949", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2767486949"},
    {workshopid = "2845684538", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2845684538"},
    {workshopid = "2845715858", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2845715858"},
    {workshopid = "2868925871", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2868925871"},
    {workshopid = "2869275908", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2869275908"},
    {workshopid = "2918443067", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2918443067"},
    {workshopid = "2925318514", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2925318514"},
    {workshopid = "2992808843", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2992808843"},
    {workshopid = "2992808903", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2992808903"},
    {workshopid = "2992808971", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\2992808971"},
    {workshopid = "3122496141", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3122496141"},
    {workshopid = "3131377152", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3131377152"},
    {workshopid = "3144281919", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3144281919"},
    {workshopid = "3148341500", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3148341500"},
    {workshopid = "3198967811", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3198967811"},
    {workshopid = "3198978315", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3198978315"},
    {workshopid = "3272120018", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3272120018"},
    {workshopid = "3347925529", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3347925529"},
    {workshopid = "3392854486", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3392854486"},
    {workshopid = "3427505201", path = "C:\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\445220\\3427505201"}
}
